import os

API_ID = int(os.getenv("API_ID", "123456"))
API_HASH = os.getenv("API_HASH", "YOUR_API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN")

CHANNEL_ID = int(os.getenv("CHANNEL_ID", "-1001234567890"))
MONGO_DB_URI = os.getenv("MONGO_DB_URI", "mongodb+srv://user:pass@cluster.mongodb.net/FileStore")

ADMINS = list(map(int, os.getenv("ADMINS", "123456789").split()))
