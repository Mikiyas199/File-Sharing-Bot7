from pyrogram import Client, filters
from config import CHANNEL_ID

@Client.on_message(filters.command("start"))
async def start(client, message):
    if len(message.command) == 1:
        await message.reply("👋 Welcome to CodeX File Store Bot")
    else:
        msg_id = int(message.command[1])
        await client.copy_message(message.chat.id, CHANNEL_ID, msg_id)
