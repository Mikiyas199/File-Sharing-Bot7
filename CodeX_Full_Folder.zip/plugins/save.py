from pyrogram import Client, filters
from config import CHANNEL_ID

@Client.on_message(filters.private & filters.media)
async def save_file(client, message):
    sent = await message.copy(CHANNEL_ID)
    link = f"https://t.me/{client.me.username}?start={sent.id}"
    await message.reply(f"✅ File Stored\n🔗 {link}")
